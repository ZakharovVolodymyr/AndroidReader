/* */
#include <sys/types.h>
#include <sys/stat.h>
#include <fts.h>


int main(void){return 0;}

