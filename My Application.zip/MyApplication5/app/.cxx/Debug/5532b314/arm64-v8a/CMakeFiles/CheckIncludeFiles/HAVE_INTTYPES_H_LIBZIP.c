/* */
#include <inttypes.h>


int main(void){return 0;}

