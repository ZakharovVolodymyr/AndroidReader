#!/bin/sh
mkdir -p m4 && \
autoreconf --force --install -I m4
